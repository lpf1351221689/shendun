/**
 * Created by Administrator on 2017/6/29.
 */
//var  fs=require("fs")
//var http=require("http")
//http.createServer(function(req,res){
//    var url=req.url;
//    switch(url){
//        case "/index.html":
//         fs.readFile("/log.html","utf-8",function(arr,data){
//            if(err){
//                console.log("没有获取到信息")
//                console.log(err)
//            }else{
//                res.writeHead(200,{"content-type":"text/html;charset:utf-8"})
//                res.end(data)
//            }
//        })
//            break;
//        case "/imdex.css":
//            fs.readFile("index.css","utf-8",function(arr,data){
//                if(err){
//                    console.log("没有获取到信息")
//                    console.log(err)
//                }else{
//                    res.writeHead(200,{"content-type":"text/css;charset:utf-8"})
//                    res.end(data)
//                }
//            })
//            break;
//        case "/index.js":
//            fs.readFile("index.js","utf-8",function(arr,data){
//                if(err){
//                    console.log("没有获取到信息")
//                    console.log(err)
//                }else{
//                    res.writeHead(200,{"content-type":"text/javascript;charset:utf-8"})
//                    res.end(data)
//                }
//            })
//            break;
//        case "/a.jpg":
//            fs.readFile("a.jpg","utf-8",function(arr,data){
//                if(err){
//                    console.log("没有获取到信息")
//                    console.log(err)
//                }else{
//                    res.writeHead(200,{"content-type":"image/jpeg;charset:utf-8"})
//                    res.end(data)
//                }
//            })
//            break;
//        case "/img.html":
//            // 处理 /demo.html的请求
//            fs.readFile("log.html", "utf-8", function (err, data) {
//                if (err) {
//                    console.log("读取失败")
//                    console.log(err);
//                } else {
//                    res.writeHead(200, {"content-type": "text/html;charset=utf8"})
//                    res.end(data)
//                }
//            });
//            break;
//
//        default:
//    }
//    console.log("404没有找到页面")
//}).listen(3000)
var fs = require('fs');
var http = require('http');
//  创建服务
http.createServer(function (req, res) {
    var url = req.url;// 用url 保存 请求地址
    console.log(url)
    switch (url) {
        case "/log.html":
            //处理  / 请求
            // 发送 index.html页面

            fs.readFile("log.html", "utf-8", function (err, data) {
                if (err) {
                    console.log("读取失败")
                    console.log(err)
                } else {
                    res.writeHead(200, {"content-type": "text/html;charset=utf8"})
                    res.end(data)
                }
            });
            break
        case "/index.css"://处理  /index.css 的请求
            fs.readFile("index.css", "utf-8", function (err, data) {
                if (err) {
                    console.log("读取失败")
                    console.log(err)
                } else {
                    //     设置响应头
                    res.writeHead(200, {"content-type": "text/css"})
                    res.end(data)
                }
            });
            break;
        case "/index.js"://处理  /index.css 的请求
            fs.readFile("index.js", "utf-8", function (err, data) {
                if (err) {
                    console.log("读取失败")
                    console.log(err)
                } else {
                    //     设置响应头
                    res.writeHead(200, {"content-type": "text/javascript"})
                    res.end(data)
                }
            });
            break;
        case "/a.jpg":
            fs.readFile("a.jpg", function (err, data) {
                if (err) {
                    console.log("读取失败")
                    console.log(err)
                } else {
                    //设置响应头
                    res.writeHead(200, {"content-type": "image/jpeg;charset=utf8"})
                    // 发送数据
                    res.end(data)
                }
            });
            break;
        case "/img.html":
            // 处理 /demo.html的请求
            fs.readFile("img.html", "utf-8", function (err, data) {
                if (err) {
                    console.log("读取失败")
                    console.log(err);
                } else {
                    res.writeHead(200, {"content-type": "text/html;charset=utf8"})
                    res.end(data)
                }
            });
            break;
        case "/img.html":
            // 处理 /demo.html的请求
            fs.readFile("img.html", "utf-8", function (err, data) {
                if (err) {
                    console.log("读取失败")
                    console.log(err);
                } else {
                    res.writeHead(200, {"content-type": "text/html;charset=utf8"})
                    res.end(data)
                }
            });
            break
        default:
            res.end("404 NOT FOUND")
    }
}).listen(3000)

