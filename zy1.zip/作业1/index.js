/**
 * Created by Administrator on 2017/6/29.
 */
    window.onload=function() {
        var oDiv = document.getElementById("a")
        oDiv.onclick = function () {
            alert("我爱北京天安门")
        }
    }