/**
 * Created by Administrator on 2017/6/29.
 */
var http=require("http");
var fs=require("fs");
http.createServer(function(req,res){
    console.log(req.url)
    //处理/的请求
    if(req.url=="/"){
        fs.readFile("index.html","utf-8",function(err,data){
            if(err){
                console.log("读取失败")
                console.log(err)
            }else{
                //设置响应头
                res.writeHead(200,{"content-type":"text/html;charset:utf-8"})
                res.end(data)
            }
        })
    }else if(req.url=="/css") {
        fs.readFile("index.css", "utf-8", function (err, data) {
            if (err) {
                console.log("读取失败")
                console.log(err)
            } else {
                //设置响应头
                res.writeHead(200, {"content-type": "text/css;charset:utf-8"})
                res.end(data)
            }
        })
    }else if(req.url=="/js") {
        fs.readFile("index.js", "utf-8", function (err, data) {
            if (err) {
                console.log("读取失败")
                console.log(err)
            } else {
                //设置响应头
                res.writeHead(200, {"content-type": "text/javascript;charset:utf-8"})
                res.end(data)
            }
        })
    }else if(req.url=="/a.jpg") {
        fs.readFile("a.jpg", function (err, data) {
            if (err) {
                console.log("读取失败")
                console.log(err)
            } else {
                //设置响应头
                res.writeHead(200, {"content-type": "image/jpeg"})
                res.end(data)
            }
        })
    }
}).listen(3000)